package com.example.flutter_teste

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
